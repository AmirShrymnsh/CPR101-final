#ifndef _FUNDAMENTALS_H								//Safeguarding the header file
#define _FUNDAMENTALS_H

#include <stdio.h>									//including standard input output library.
#include <stdlib.h>									//including standard library which has predefined functions such as atoi().
#include <string.h>									//including the header in standard library to use string functions.

void fundamentals();								//Function prototype declared here in the header file

#endif
